# Luke

Luke est une application web de gestion de projet inspiree de Trello. Elle propose des espaces d'entreprise isoles, la gestion des projets et des collaborateurs, ainsi qu'un tableau Kanban avec deplacement des cartes.

## Demarrage

Prerequis : Docker avec Docker Compose.

A la racine du projet :

```sh
docker compose up -d --build
```

Ouvrir ensuite <http://localhost:8000>. Au premier demarrage, Luke cree deux espaces de demonstration, un projet, des membres et quelques cartes. Dans l'espace ? Atelier Nova ?, le projet ? Refonte du site ? permet d'essayer les colonnes, les filtres, le deplacement des taches, les etiquettes et la progression.

Arreter les conteneurs :

```sh
docker compose down
```

Les donnees MongoDB sont conservees dans le volume Docker `mongodb_data`. Pour les reinitialiser, utilisez `docker compose down -v`.

## Configuration MongoDB

Compose utilise `MONGO_URI`, par defaut `mongodb://mongodb:27017/luke_db`. Pour personnaliser la connexion, copiez `.env.example` en `.env` et modifiez `MONGO_URI`. Une URI de replica set ou de routeur `mongos` fonctionne sans modifier le code applicatif.

```env
MONGO_URI=mongodb://mongodb:27017/luke_db
```

## Fonctionnalites

- Creation d'entreprises et selecteur d'espace de travail pour illustrer l'isolation multi-tenant.
- Creation, modification, archivage et suppression des projets, avec gestion de leurs membres.
- Ajout de collaborateurs et gestion de leurs roles.
- Creation, modification et suppression des taches, avec assignation, priorite, echeance et etiquettes.
- Tableau Kanban a quatre colonnes, glisser-deposer et reorganisation verticale.
- Filtres par collaborateur, raccourci ? Mes taches ? et priorite.
- Calcul automatique du taux d'avancement des taches terminees.
- Suppression en cascade des projets et entreprises, et controle de l'appartenance des membres et taches a la meme entreprise.

## API et donnees

La documentation interactive FastAPI est disponible sur <http://localhost:8000/docs>. MongoDB utilise quatre collections : `companies`, `users`, `projects` et `tasks`. Les utilisateurs, projets et taches portent `company_id` pour l'isolation et la preparation au sharding. Les index couvrent le slug, l'email par entreprise, les membres des projets et l'ordre des taches Kanban.

## Limite du prototype

Cette version pedagogique ne comporte ni authentification ni gestion de session. Les routes filtrent les donnees a partir du `company_id` de l'URL. En production, ce contexte devra provenir d'une identite authentifiee et autorisee. L'interface ne collecte pas de mots de passe.
